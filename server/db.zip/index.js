const Room = require('./room');
const Score = require('./score');

//ASSOCIATIONS

module.exports = {Room, Score};